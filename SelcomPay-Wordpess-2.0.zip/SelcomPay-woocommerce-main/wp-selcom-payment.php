<?php
/**
 * Plugin Name: WP Selcom Payment Gateway
 * Plugin URI: https://selcom.net
 * Description: Selcom Payment Method.
 * Author: Selcom Payment Ltd.
 * Author URI: https://selcom.net
 * Version: 2.0.0
 * Text Domain: wp-selcom-payment-gateway
 */

defined('ABSPATH') or exit;

// Make sure WooCommerce is active
if (!in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' )))) {
	return;
}

/**
 * Add the gateway to WC Available Gateways
 * 
 * @since 1.0.0
 * @param array $gateways all available WC gateways
 * @return array $gateways all WC gateways + SelcomPaymentGateway
 */
function wp_selcom_payment_add_to_gateways($gateways) {
	$gateways[] = 'WP_Selcom_Payment_Gateway';
	return $gateways;
}

add_filter('woocommerce_payment_gateways', 'wp_selcom_payment_add_to_gateways');

/**
 * Adds plugin page links
 * 
 * @since 1.0.0
 * @param array $links all plugin links
 * @return array $links all plugin links + selcom settings link
 */
function wp_selcom_payment_gateway_plugin_links($links) {

	$plugin_links = array(
		'<a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=wp_selcom_payment_gateway' ) . '">' . __( 'Configure', 'wp-selcom-connect' ) . '</a>'
	);

	return array_merge($plugin_links, $links);
}

add_filter('plugin_action_links_' . plugin_basename( __FILE__ ), 'wp_selcom_payment_gateway_plugin_links');

/**
 * Selcom Payment Gateway
 *
 * Provides a Selcom Payment Gateway.
 * We load it later to ensure WC is loaded first since we're extending it.
 *
 * @class 		WP_Selcom_Payment_Gateway
 * @extends		WC_Payment_Gateway
 * @version		1.0.0
 * @package		WooCommerce/Classes/Payment
 * @author 		Selcom
 */
add_action('plugins_loaded', 'wp_selcom_payment_gateway_init', 11);

function wp_selcom_payment_gateway_init() {

	class WP_Selcom_Payment_Gateway extends WC_Payment_Gateway {

		/**
		 * Constructor for the gateway.
		 */
		public function __construct() {
			if (!session_id()) {
				session_start();
			}

			$this->id                 	= 'wp_selcom_payment_gateway';
			$this->icon               	= apply_filters('wp_selcom_icon', plugins_url('assets/images/selcom.png' , __FILE__));
			$this->has_fields         	= false;
			$this->method_title       	= __('Selcom Payment Gateway', $this->id);
			$this->method_description 	= __('Payment Gateway from Selcom Payment Ltd', $this->id);
			//$this->url					= 'https://apigw.selcommobile.com/v1/'; //LIVE
			$this->url					= 'https://apigwtest.selcommobile.com/v1/'; //TEST
			
			// Load the settings.
			$this->init_form_fields();
			$this->init_settings();
		  
			// Define user set variables
			$this->title        = $this->get_option('title');
			$this->description  = $this->get_option('description');
			$this->instructions = $this->get_option('instructions', $this->description);
			$this->order_status = $this->get_option('order_status', 'pending');
			$this->merchant_id  = $this->get_option('merchant_id');
			$this->api_key      = $this->get_option('api_key');
			$this->secret_key   = $this->get_option('secret_key');
			$this->payment_methods = $this->get_option('payment_methods');
			
			$selected_payment_method = isset($_SESSION['selected_payment_method'])? $_SESSION['selected_payment_method']:array();
			
			$this->cancel_url = $this->get_option('cancel_url');
			$this->redirect_url = $this->get_option('redirect_url');
			
			
			// Attach filter if enabled
			if ($this->get_option('enabled') === 'yes') {

				$selected_methods = $this->payment_methods;
				
				if (in_array('ALL', $selected_methods)) {
					$payment_optionss = 'all';
				}else if(in_array('CARD', $selected_methods)){
					$payment_optionss = 'all';
				}else if(in_array('MOBILEMONEYPULL', $selected_methods)){
					$payment_optionss = 'pull_payment';
				}else if(in_array('MASTERPASS', $selected_methods)){
					$payment_optionss = 'pull_payment';
				}

				$this->payment_optionss = $payment_optionss;

				if(in_array('ALL', $selected_methods)){
					add_action('woocommerce_review_order_before_submit', array($this, 'display_custom_payment_section'));
					add_filter('woocommerce_checkout_fields', array($this, 'wc_set_def_val'));
				}else if(in_array('CARD', $selected_methods) && ( in_array('MOBILEMONEYPULL', $selected_methods) || in_array('MASTERPASS', $selected_methods) ) ){
					add_action('woocommerce_review_order_before_submit', array($this, 'display_custom_payment_section'));
					add_filter('woocommerce_checkout_fields', array($this, 'wc_set_def_val'));
				}else{
					if($this->payment_optionss == 'pull_payment'){
						add_filter('woocommerce_checkout_fields', array($this, 'wc_remove_checkout_fields'));
					}
				}

				if(in_array('MOBILEMONEYPULL', $selected_payment_method) || in_array('MASTERPASS', $selected_payment_method)){
					add_filter('woocommerce_checkout_fields', array($this, 'wc_remove_checkout_fields'));
				}else{
					add_filter('woocommerce_checkout_fields', array($this, 'wc_set_def_val'));
				}

			}
			
			// Actions
			add_action('woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options') );
			add_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page' ) );
			add_action('woocommerce_api_' . $this->id, array( $this, 'process_response' ));
			//add_filter( 'woocommerce_gateway_description', array( $this, 'gateway_salcon_custom_fields' ), 20, 2 );

			// Customer Emails
			add_action('woocommerce_email_before_order_table', array( $this, 'email_instructions'), 10, 3);

			add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'reset_payment_session']);
		}

		/**
		 * Reset payment session after settings save.
		 */
		public function reset_payment_session() {
			if (isset($_SESSION['selected_payment_method'])) {
				unset($_SESSION['selected_payment_method']);
			}
		}

		public function display_custom_payment_section() {
			if (!session_id()) {
				session_start();
			}
			
			// Check and get the first selected payment method from the session array
			$selected_payment_method = isset($_SESSION['selected_payment_method']) ? $_SESSION['selected_payment_method'] : array();
			
			if(in_array('ALL', $this->payment_methods)){
				echo '<div id="custom-payment-options" style="margin-bottom: 15px;">';
				echo '<h3>' . __('Payment Method') . '</h3>';
				
				echo '<label><input type="radio" name="custom_payment_method" value="CARD"' . (in_array('CARD', $selected_payment_method, true) ? ' checked' : '') . ' checked> Card</label>';

				echo '<label><input type="radio" name="custom_payment_method" value="MASTERPASS"' . (in_array('MASTERPASS', $selected_payment_method, true) ? ' checked' : '') . '> TanQr</label>';

				echo '<label><input type="radio" name="custom_payment_method" value="MOBILEMONEYPULL"' . (in_array('MOBILEMONEYPULL', $selected_payment_method, true) ? ' checked' : '') . '> Mobile Money</label>';

				echo '</div>';
			}else if(in_array('CARD', $this->payment_methods) && in_array('MASTERPASS', $this->payment_methods)){
				echo '<div id="custom-payment-options" style="margin-bottom: 15px;">';
				echo '<h3>' . __('Payment Method') . '</h3>';
				
				echo '<label><input type="radio" name="custom_payment_method" value="CARD"' . (in_array('CARD', $selected_payment_method, true) ? ' checked' : '') . ' checked> Card</label>';

				echo '<label><input type="radio" name="custom_payment_method" value="MASTERPASS"' . (in_array('MASTERPASS', $selected_payment_method, true) ? ' checked' : '') . '> TanQr</label>';

				echo '</div>';
			}else if(in_array('CARD', $this->payment_methods) && in_array('MOBILEMONEYPULL', $this->payment_methods)){
				echo '<div id="custom-payment-options" style="margin-bottom: 15px;">';
				echo '<h3>' . __('Payment Method') . '</h3>';
				
				echo '<label><input type="radio" name="custom_payment_method" value="CARD"' . (in_array('CARD', $selected_payment_method, true) ? ' checked' : '') . ' checked> Card</label>';

				echo '<label><input type="radio" name="custom_payment_method" value="MOBILEMONEYPULL"' . (in_array('MOBILEMONEYPULL', $selected_payment_method, true) ? ' checked' : '') . '> Mobile Money</label>';
				
				echo '</div>';
			}
			
			// Add custom JavaScript to handle enabling/disabling fields
			?>
			<script type="text/javascript">
				jQuery(document).ready(function($) {
					$("input[name='custom_payment_method']").change(function () {
						var selectedMethod = $(this).val();

						// Send the selected payment method via AJAX
						$.post(
							'<?php echo admin_url('admin-ajax.php'); ?>',
							{
								action: 'set_payment_method',
								payment_method: selectedMethod
							},
							function (response) {
								if (response.success) {
									location.reload(); // Reload the page to apply changes
								} else {
									alert('Error updating payment method.');
								}
							}
						);
					});
				});
			</script>
			<?php
		}

		public function wc_set_def_val($fields){
			
			// Add custom script to clear values when payment method changes
			add_action('wp_footer', function () {
				if (is_checkout()) {
					echo '<script>
						jQuery(document).ready(function($) {
							
							// Reset specific billing fields to blank
							$("#billing_address_1, #billing_city, #billing_postcode, #billing_email, #billing_state, #billing_country").val("");
							
						});
					</script>';
				}
			});
			
			return $fields;
		}

		// Remove checkout fields and set static values
		public function wc_remove_checkout_fields($fields) {
			
			// Set default static values
			$fields['billing']['billing_country']['default'] = 'TZ'; // Example for default country
			$fields['billing']['billing_address_1']['default'] = 'Dar es Salaam';
			$fields['billing']['billing_city']['default'] = 'Dar es Salaam';
			$fields['billing']['billing_postcode']['default'] = '12345';
			$fields['billing']['billing_email']['default'] = 'joe@example.com';
			$fields['billing']['billing_state']['default'] = 'Dar es Salaam';

			// Hide and disable the fields instead of unsetting
			$disabledFields = ['billing_email', 'billing_state', 'billing_address_1', 'billing_address_2', 'billing_city', 'billing_postcode', 'billing_country', 'billing_company'];

			foreach ($disabledFields as $field) {
				if (isset($fields['billing'][$field])) {
					$fields['billing'][$field]['required'] = false;
					$fields['billing'][$field]['type'] = 'hidden';
					$fields['billing'][$field]['label'] = false; // Remove label
				}
			}

			// Add custom script to clear values when payment method changes
			add_action('wp_footer', function () {
				if (is_checkout()) {
					echo '<script>
						jQuery(document).ready(function($) {
							
							// Reset specific billing fields to blank
							$("#billing_address_1").val("Dar es Salaam");
							$("#billing_email").val("joe@example.com");
							$("#billing_state").val("Dar es Salaam");
							$("#billing_city").val("Dar es Salaam");
							$("#billing_country").val("TZ");
							$("#billing_postcode").val("12345");
							
						});
					</script>';
				}
			});

			// Inject CSS to hide WooCommerce billing fields
			add_action('wp_head', function () {
				if (is_checkout()) {
					echo '<style>
						.woocommerce-billing-fields .form-row {
							display: none !important;
							margin: 0 !important;
							padding: 0 !important;
						}
					</style>';

					echo '<style>
						.woocommerce-billing-fields .validate-required {
							display: block !important;
						}
					</style>';
				}
			});
			return $fields;
		}

		/**
		 * Initialize Gateway Settings Form Fields
		 */
		public function init_form_fields() {
	  
			$this->form_fields = apply_filters('wp_selcom_payment_gateway_form_fields', array(
				'enabled' => array(
					'title'   => __('Enable/Disable', $this->id),
					'type'    => 'checkbox',
					'label'   => __('Enable Selcom Payment Gateway', $this->id),
					'default' => 'yes'
				),
				'title' => array(
					'title'       => __('Title', $this->id),
					'type'        => 'text',
					'description' => __('This controls the title for the payment method the customer sees during checkout.', $this->id),
					'default'     => __('', $this->id),
					'desc_tip'    => true,
				),
				'description' => array(
					'title'       => __('Description', $this->id),
					'type'        => 'text',
					'description' => __('Pay by card or mobile money', $this->id),
					'default'     => __('You will be redirected to Selcom.', $this->id),
					'desc_tip'    => true,
				),
				'merchant_id' => array(
					'title'       => __('Vendor/Merchant ID', $this->id),
					'type'        => 'text',
					'description' => __('You can find your merchant ID under the security settings section', $this->id),
					'default'     => '',
					'desc_tip'    => true,
					'placeholder' => ''
				),
				'api_key'         => array(
					'title'       => __('API Key', $this->id),
					'type'        => 'text',
					'description' => __('You can find your API key under the security settings section', $this->id),
					'default'     => '',
					'desc_tip'    => true,
					'placeholder' => ''
				),
				'secret_key'      => array(
					'title'       => __('Secret Key', $this->id),
					'type'        => 'text',
					'description' => __('You can find your secret key under the security settings section.', $this->id),
					'default'     => '',
					'desc_tip'    => true,
					'placeholder' => ''
				),
				'payment_methods' => array(
					'title'       => __( 'Payment Methods', $this->id ),
					'type'        => 'multiselect',
					'description' => __( 'Select Payment Methods', $this->id ),
					'options'     => array(
						'ALL' => __( 'ALL', $this->id ),
						'MASTERPASS' => __( 'MASTERPASS', $this->id ),
						'CARD'  => __( 'CARD', $this->id ),
						'MOBILEMONEYPULL' => __( 'MOBILEMONEYPULL', $this->id ),
					),
					'default'     => array('ALL'), // Default selected
				),
				'redirect_url' => array(
					'title'       => __('Redirect URL', $this->id),
					'type'        => 'text',
					'description' => __('Redirect URL', $this->id),
					'default'     => '',
					'desc_tip'    => true,
					'placeholder' => ''
				),
				'cancel_url' => array(
					'title'       => __('Cancel URL', $this->id),
					'type'        => 'text',
					'description' => __('Cancel URL', $this->id),
					'default'     => '',
					'desc_tip'    => true,
					'placeholder' => ''
				),
				'successful_status'          => array(
					'title'       => __( 'Successful Order Status',$this->id ),
					'type'        => 'select',
					'description' => __( 'Define order status if transaction successful. If status is "On Hold" then stock will NOT be reduced automaticlly',
						$this->id ),
					'options'     => array(
						'processing' => __( 'Processing',$this->id ),
						'completed'  => __( 'Completed', $this->id),
						'on-hold'    => __( 'On Hold', $this->id ),
					),
					'default'     => 'processing',
				),
			) );
		}
	
		/**
		 * Output for the order received page.
		 */
		public function thankyou_page() {
			if ( $this->instructions ) {
				echo wpautop( wptexturize( $this->instructions ) );
			}
		}
	
		/**
		 * Add content to the WC emails.
		 *
		 * @access public
		 * @param WC_Order $order
		 * @param bool $sent_to_admin
		 * @param bool $plain_text 
		 */
		public function email_instructions($order, $sent_to_admin, $plain_text = false) {
		
			if ($this->instructions && ! $sent_to_admin && $this->id === $order->payment_method && $order->has_status( 'on-hold')) {
				echo wpautop( wptexturize($this->instructions)) . PHP_EOL;
			}
		}
	
		/**
		 * Process the payment and return the result
		 *
		 * @param int $order_id
		 * @return array
		 */
		public function process_payment($order_id) {

			global $woocommerce;
			if (!session_id()) {
				session_start();
			}
			/* if($this->check_order_is_exits($order_id)){

				$oldorder = wc_get_order($order_id);

				$new_id = $this->duplicate_order( $oldorder );

				// If you have written a plugin which uses non-WP database tables to save
				// information about a page you can hook this action to dupe that data.
				// TODO: Document this hook
				do_action( 'woocommerce_duplicate_order', $new_id, $oldorder );

				$order = wc_get_order($new_id);	
				$order->update_status('Pending payment');
			}else{
				$order = wc_get_order($order_id);
			} */

			$order = wc_get_order($order_id);

			$isPost = 1;

			$userId = get_current_user_id();
			
			if(!empty($userId)){

				$get_gateway_buyer_uuid = get_user_meta( $userId, 'gateway_buyer_uuid', true );
  	  	        $get_buyer_userid = get_user_meta( $userId, 'buyer_userid', true );


				if($get_gateway_buyer_uuid  == null){
					$gateway_buyer_uuid = "AGET".rand();
  	    		}else{
  	    			$gateway_buyer_uuid = $get_gateway_buyer_uuid;
  	    		}

  	    		if($get_buyer_userid == null){
  	    			$buyer_userid = "user".$userId.rand();
  	    		}else{
  	    			$buyer_userid = $get_buyer_userid;
  	    		}
				
			}else{
				$buyer_userid = "user".rand();
				$gateway_buyer_uuid = "AGET".rand();
			}
			
			if ( isset($_POST['salcon_payment_options']) ){
				$payment_optionss = sanitize_text_field( $_POST['salcon_payment_options'] );
			}

			/* ALL -  create-order
			MASTERPASS - create-order-minimal
			CARD  create-order
			MOBILEMONEYPULL - create-order-minimal */
			$selected_methods = $this->get_option('payment_methods', array());
			if (in_array('ALL', $selected_methods)) {
				$payment_optionss = 'all';
			}else if(in_array('CARD', $selected_methods)){
				$payment_optionss = 'all';
			}else if(in_array('MOBILEMONEYPULL', $selected_methods)){
				$payment_optionss = 'pull_payment';
			}else if(in_array('MASTERPASS', $selected_methods)){
				$payment_optionss = 'pull_payment';
			}

			$selected_payment_method = isset($_SESSION['selected_payment_method'])? $_SESSION['selected_payment_method']:array();
			if(!empty($selected_payment_method)){
				if(in_array('ALL', $selected_payment_method)){
					$payment_optionss = 'all';
				}else if(in_array('CARD', $selected_payment_method)){
					$payment_optionss = 'all';
				}else if(in_array('MOBILEMONEYPULL', $selected_payment_method) || in_array('MASTERPASS', $selected_payment_method)){
					$payment_optionss = 'pull_payment';
				}
			}

			if(empty($this->cancel_url)){
				$cancel_url = wc_get_checkout_url();
			}else{
				$cancel_url = $this->cancel_url;
			}

			if(empty($this->redirect_url)){
				$redirect_url = get_site_url().'/wc-api/' . $this->id.'?order_id='.$order->get_id();
			}else{
				$redirect_url = $this->redirect_url.'?order_id='.$order->get_id();
			}
			
			

			if($payment_optionss == "pull_payment"){

				$buyer_email = $order->get_billing_email();
				if(empty($buyer_email)){
					$buyer_email = 'joe@example.com';
				}

				$req = array(
					'vendor' => $this->merchant_id,
					'order_id' => $order->get_id(),
					'buyer_email' => $buyer_email,
					'buyer_name' => $order->get_billing_first_name() ." ". $order->get_billing_last_name(),
					//'buyer_userid'=> $buyer_userid,
					'buyer_phone' => $order->get_billing_phone(),
					'cancel_url' => base64_encode($cancel_url),
					//'redirect_url' => base64_encode($this->get_return_url($order)),
					'redirect_url' => base64_encode($redirect_url),
					'webhook' => base64_encode(get_site_url().'/wc-api/' . $this->id),
					'amount' => (int) $order->get_total(),
					'currency' =>'TZS',
					'buyer_remarks' => $order->get_billing_first_name() ." ". $order->get_billing_last_name(),
					'merchant_remarks' => 'None',
					'no_of_items' => 1
				);
				$api_endpoint = "checkout/create-order-minimal";

            }else{
            	$req = array(
					'vendor' => $this->merchant_id,
					'order_id' => $order->get_id(),
					'buyer_email' => $order->get_billing_email(),
					'buyer_name' => $order->get_billing_first_name(),
					'buyer_userid'=> $buyer_userid,
					'buyer_phone' => $order->get_billing_phone(),
					'gateway_buyer_uuid' => $gateway_buyer_uuid,
					'cancel_url' => base64_encode($cancel_url),
					//'redirect_url' => base64_encode($this->get_return_url($order)),
					'redirect_url' => base64_encode($redirect_url),
					'webhook' => base64_encode(get_site_url().'/wc-api/' . $this->id),
					'amount' => (int) $order->get_total(),
					'currency' =>$order->get_currency(), //"TZS", 
					'payment_methods' => 'ALL',
					'billing.firstname' => $order->get_billing_first_name(),
					'billing.lastname' => $order->get_billing_last_name(),
					'billing.address_1' => $order->get_billing_address_1(),
					'billing.address_2' => $order->get_billing_address_2(),
					'billing.city' => $order->get_billing_city(),
					'billing.state_or_region' => $order->get_billing_state(),
					'billing.postcode_or_pobox' => $order->get_billing_postcode(),
					'billing.country' => $order->get_billing_country(),
					'billing.phone' => $order->get_billing_phone(),
					'buyer_remarks' => $order->get_customer_note(),
					'merchant_remarks' => 'None',
					'no_of_items' => $woocommerce->cart->cart_contents_count
				);
				$api_endpoint = "checkout/create-order";
            }
			
    		date_default_timezone_set('Africa/Dar_es_Salaam');
			
			$authorization = base64_encode($this->api_key);
			
			$timestamp = date('c');

			$signed_fields  = implode(',', array_keys($req));

			$digest = $this->computeSignature($req, $signed_fields, $timestamp, $this->secret_key);

		    $url = $this->url.$api_endpoint;
			 
			$response = $this->sendJSONPost($url, $isPost, json_encode($req), $authorization, $digest, $signed_fields, $timestamp);
			/* echo "<pre>";
			print_r($response);
			exit; */

			if ($response['resultcode'] == 000) {
				
				if(!empty($userId)){
						if($get_gateway_buyer_uuid == null ){
							update_user_meta($userId, 'gateway_buyer_uuid', $response['data'][0]['gateway_buyer_uuid'] );
					}

					if($get_buyer_userid == null){
							update_user_meta($userId, 'buyer_userid', $buyer_userid);
					}	
				}
			   
			   	if($payment_optionss == "pull_payment"){
					
		            $first_order = get_user_meta( $userId, 'first_order', true );
					//print_r($first_order);
				
					if($first_order == null){

						//print_r("first_order");
				
						update_user_meta( $userId, 'first_order', "Yes" );
				    }

				    //exit();
					return array(
						'result' 	=> 'success',
						'redirect'	=> base64_decode($response['data'][0]['payment_gateway_url'])
					);

				}else if($this->payment_optionss == "card_payment"){

					if ( isset($_POST['salcon_payment_card_token']) ){

						
		                $transid = substr(strtoupper('SPW'.md5(time().$order->get_id().rand (10,1000))),0,8);
		   				$vendor = $this->merchant_id;
		   				$order_id = $order->get_id();
		   				$salcon_payment_card_token = sanitize_text_field( $_POST['salcon_payment_card_token'] );
						$gateway_buyer_uuid = get_user_meta( $userId, 'gateway_buyer_uuid', true );
		   				$buyer_userid = get_user_meta( $userId, 'buyer_userid', true );

		   				$req_params = array(

		   					"transid" =>  $transid,
		   					"vendor"  =>  $vendor,
		   					"order_id"  =>  $order_id,
		   					"card_token"  =>  $salcon_payment_card_token,
		   					"buyer_userid"  =>  $buyer_userid,
		   					"gateway_buyer_uuid"  =>  $gateway_buyer_uuid,

		   				);

		   				$pay_resp =  $this->sendCardPayment ($req_params);

						if ($pay_resp["result"] == 'FAIL') {
			               //Update order status
			               $order->update_status('failed', __( 'Payment unsuccessful.', $this->id ));

			               //Display error message
			               wc_add_notice( __('Error: ',  $this->id) . ' '. $pay_resp["message"] , 'error' );

			            }else if ($pay_resp["result"] == 'SUCCESS' && $pay_resp["payment_status"] =='COMPLETE') {
			               //Payment successfully initiated, update order status
			               $order->update_status('processing', __( 'Payment processed successfully. Awaiting delivery.', $this->id ));

			               //Update update stock & cart information
			               WC()->cart->empty_cart();
			               wc_reduce_stock_levels($order);

			               //Return to thank you page
			               return array(
			                  'result' => 'success',
			                  'redirect' => $this->get_return_url( $order )
			               );

			            }else {
			               //Update order status
			               $order->update_status('on-hold', __( 'Payment is on hold.', $this->id ));

						   if(isset($pay_resp["payment_status"])){
							$err = $pay_resp["payment_status"];
						   }else{
							$err = 'Something went wrong during payment.';
						   }

			               //Display error message
			               wc_add_notice( __('Payment error: ', $this->id) . $err, 'error' );
			            }

					}

				}else{

					$first_order = get_user_meta( $userId, 'first_order', true );
					//print_r($first_order);
				
					if($first_order == null){

						//print_r("first_order");
				
						update_user_meta( $userId, 'first_order', "Yes" );
				    }

				    //exit();
					return array(
						'result' 	=> 'success',
						'redirect'	=> base64_decode($response['data'][0]['payment_gateway_url'])
					);	

				}
		
			} else {
			        
				if(isset($response['message'])){
					$err = $response['message'];
				}else{
					$err = 'Something went wrong during payment.';
				}

			    wc_add_notice( __('Payment error: ', $this->id) . $err, 'error' );
				
				return array(
					'result' 	=> 'fail',
					'error_msg' => 'Payment unsuccessful.',
					'redirect'	=> $this->get_return_url( $order )
				);
			}
		}

		/**
		 * Compute the signature and return the digest
		 *
		 * @param array $parameters
		 * @param string $signed_fields
		 * @param string $request_timestamp
		 * @param string $api_secret
		 * @return string Base64 encoded HMAC SHA256 or RSA signature of data in the format
		 */
		public function computeSignature($parameters, $signed_fields, $request_timestamp, $api_secret){
			$fields_order = explode(',', $signed_fields);
			$sign_data = "timestamp=$request_timestamp";
			foreach ($fields_order as $key) {
				$sign_data .= "&$key=".$parameters[$key];
			}
			return base64_encode(hash_hmac('sha256', $sign_data, $api_secret, true));
		}
		
		/**
		 * Webhook 
		 *
		 * @param int $order_id
		 * @return array
		 */
		public function process_response() {
   	       
			global $woocommerce;

			$order_id = isset($_REQUEST['order_id']) ? $_REQUEST['order_id'] : null;
            
			$order = wc_get_order( $order_id );
			$payment_status = isset($_REQUEST['payment_status']) ? $_REQUEST['payment_status'] : "Failed";
			
			if ($payment_status == 'COMPLETED') {
				$transid =  isset($_REQUEST['transid']) ? $_REQUEST['transid'] : null;

				$woocommerce->cart->empty_cart();
				$order->add_order_note(sprintf( __( 'Payment completed successfully. Transaction ID %s.', $this->id ), $transid ));
				$order->payment_complete($transid);

				wp_redirect($this->get_return_url($order));
				exit;
			} else {

							// LOAD THE WC LOGGER
			   $logger = wc_get_logger();
			    
			   // LOG THE FAILED ORDER TO CUSTOM "failed-orders" LOG
			   $logger->info( wc_print_r( $_REQUEST, true ), array( 'source' => 'failed-orders' ) );	

				//$order->add_order_note(__('Sorry, your payment failed. Please try again in a few minutes or contact Selcom for further assistance.', $this->id) );
				wc_add_notice(__('Sorry, your payment failed. Please try again in a few minutes or contact Selcom for further assistance.', $this->id), 'error' );
			}
			// reaching this line means there is an error, redirect back to checkout page
			wp_redirect(wc_get_checkout_url());
			exit;
		}

		public function sendJSONPost($url, $isPost, $json, $authorization, $digest, $signed_fields, $timestamp) {
			$headers = array(
			  "Content-type: application/json;charset=\"utf-8\"", "Accept: application/json", "Cache-Control: no-cache",
			  "Authorization: SELCOM $authorization",
			  "Digest-Method: HS256",
			  "Digest: $digest",
			  "Timestamp: $timestamp",
			  "Signed-Fields: $signed_fields",
			);
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
    		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    		curl_setopt($ch, CURLOPT_ENCODING, '');
     		curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
        	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        	curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        	
			if ($isPost) {
			  curl_setopt($ch, CURLOPT_POST, 1);
			  curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
			}
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
			curl_setopt($ch,CURLOPT_TIMEOUT,90);
			$result = curl_exec($ch);
			curl_close($ch);
			$resp = json_decode($result, true);
			
			return $resp;
        }


        public function check_order_is_exits($order_id) {
    		$authorization = base64_encode($this->api_key);
			$timestamp = date('c');
			$signed_fields = "order_id";
            $req = array('order_id' => $order_id);
            $url = $this->url.'v1/checkout/order-status?order_id='.$order_id;
            $digest = $this->computeSignature($req, $signed_fields, $timestamp, $this->secret_key);
			$response = $this->sendJSONPost($url, 0, json_encode($req), $authorization, $digest, $signed_fields, $timestamp);

            if ($response['resultcode'] == 000) {
               return true;	
			}else{
	           return false ;
			}
        }
        
        public function check_order_statuses($order_id) {
            $authorization = base64_encode($this->api_key);
			$timestamp = date('c');
			$signed_fields = "order_id";
            $req = array('order_id' => $order_id);
            $url = $this->url.'v1/checkout/order-status?order_id='.$order_id;
            $digest = $this->computeSignature($req, $signed_fields, $timestamp, $this->secret_key);
			$response = $this->sendJSONPost($url, 0, json_encode($req), $authorization, $digest, $signed_fields, $timestamp);
            $order = wc_get_order($order_id);
            
            if ($response['resultcode'] == 000) {
                if ($response['data'][0]['payment_status'] == "COMPLETED") {
                    $order->update_status('completed');
                    $order->add_order_note(__('Payment accepted by Selcom. Order status changed to Completed.', $this->id));
                }
            } else {
               $order->add_order_note( __($response['message'], $this->id) );
            }
        }



		//Initiating payment via Push USSD
		public function sendUSSDPush ($push_req) {
		   //Set API endpoint
		    $api_endpoint = "/checkout/wallet-payment";

		    $url = $this->url.$api_endpoint;
		    $isPost =1;
		  
 		    $authorization = base64_encode($this->api_key);
			
			$timestamp = date('c');

			$signed_fields  = implode(',', array_keys($push_req));

			$digest = $this->computeSignature($push_req, $signed_fields, $timestamp, $this->secret_key);
			 
            return $this->sendJSONPost($url, $isPost, json_encode($push_req), $authorization, $digest, $signed_fields, $timestamp);
		}

		public function sendCardPayment ($push_req) {
		   //Set API endpoint
		    $api_endpoint = "/checkout/card-payment";

		    $url = $this->url.$api_endpoint;
		    $isPost =1;
		  
 		    $authorization = base64_encode($this->api_key);
			
			$timestamp = date('c');

			$signed_fields  = implode(',', array_keys($push_req));

			$digest = $this->computeSignature($push_req, $signed_fields, $timestamp, $this->secret_key);
			 
            return $this->sendJSONPost($url, $isPost, json_encode($push_req), $authorization, $digest, $signed_fields, $timestamp);
		}

		public function fetchStoredCardData() {
			
			$userId = get_current_user_id();

			$gateway_buyer_uuid = get_user_meta( $userId, 'gateway_buyer_uuid', true );
			$getbuyer_userid = get_user_meta( $userId, 'buyer_userid', true );
		

			if($gateway_buyer_uuid == null || $gateway_buyer_uuid == null) return;
			

			$push_req = array(
				"buyer_userid"       => $getbuyer_userid,
				"gateway_buyer_uuid" => $gateway_buyer_uuid
			);

		   //Set API endpoint
		    $api_endpoint = "/checkout/stored-cards";

		    $url = $this->url.$api_endpoint;
		    $isPost =0;
		  
 		    $authorization = base64_encode($this->api_key);
			
			$timestamp = date('c');

			$signed_fields  = implode(',', array_keys($push_req));

			$digest = $this->computeSignature($push_req, $signed_fields, $timestamp, $this->secret_key);


            return $this->sendJSONPost($url, $isPost, json_encode($push_req), $authorization, $digest, $signed_fields, $timestamp);
		}

		public function gateway_salcon_custom_fields( $description, $payment_id ){
		    //

			if( 'wp_selcom_payment_gateway' === $payment_id ){
		        ob_start(); // Start buffering

     			$userId = get_current_user_id();

		        $first_order = get_user_meta( $userId, 'first_order', true );
		        $cardPay = false;

		        if(isset($first_order) && $first_order == 'Yes'){

		        	$card_details = $this->fetchStoredCardData();
		        
		        	if(!empty($card_details)){
						if ($card_details['result'] != "FAIL") {
							$cardPay = true;
						}else{
							$cardPay = false;
						}
					}else{
						$cardPay = false;
					}

		        }else{
				   	$cardPay = false;
                }

                if($cardPay){

                	$payment_types = array(
				        'card_payment'  => __("Pay by card", $this->id),
		                'pull_payment'  => __("Pay by mobile money", $this->id),
		            );

		            $card_info = [];
					foreach ($card_details['data'] as $key => $value) {
						$card_info["card_token"] = $value['name']." ".$value['masked_card'];
					}

                }else{

                	$payment_types = array(
		                ''          => __("Pay by card", $this->id),
		                'pull_payment'  => __("Pay by mobile money", $this->id),
		            );

                }

	            echo '<div  class="wp_selcom_payment_gateway-fields" style="padding:10px 0;">';

		        woocommerce_form_field( 'salcon_payment_options', array(
		            'type'          => 'select',
		            'label'         => __("Choose another payment option", $this->id),
		            'class'         => array('form-row-wide'),
		            'required'      => false,
		            'options'       => $payment_types
		        ), '');

		        if(!empty($card_info)){

		        	woocommerce_form_field( 'salcon_payment_card_token', array(
				            'type'          => 'select',
				            'label'         => __("Select card scheme", $this->id),
				            'class'         => array('form-row-wide'),
				            'required'      => false,
				            'options'       => $card_info,
				        ), '');
				}

				echo '<div>';


		        $description .= ob_get_clean(); // Append buffered content
		    }
		    return $description;
		}


				/**
		 * Function to create the duplicate of the order.
		 *
		 * @param mixed $post
		 * @return int
		 */
		public function duplicate_order( $post ) {
			global $wpdb;

			$original_order_id = $post->id;
			$original_order = $post;

			$order_id = $this->create_order($original_order_id);

			if ( is_wp_error( $order_id ) ){
				$msg = 'Unable to create order: ' . $order_id->get_error_message();;
				throw new Exception( $msg );
			} else {

				$order = new WC_Order($order_id);

				$this->duplicate_order_header($original_order_id, $order_id);
				$this->duplicate_billing_fieds($original_order_id, $order_id);
				$this->duplicate_shipping_fieds($original_order_id, $order_id);

				$this->duplicate_line_items($original_order, $order_id);
				$this->duplicate_shipping_items($original_order, $order_id);
				$this->duplicate_coupons($original_order, $order_id);
				$this->duplicate_payment_info($original_order_id, $order_id, $order);
	      		$order->calculate_taxes();
				$this->add_order_note($original_order_id, $order);

				return $order_id;
			}
		}

		private function create_order($original_order_id) {
			$new_post_author    = wp_get_current_user();
			$new_post_date      = current_time( 'mysql' );
			$new_post_date_gmt  = get_gmt_from_date( $new_post_date );

			$order_data =  array(
				'post_type'     => 'shop_order',
		        'post_title'    => sprintf( __( 'Auto-Ship Order &ndash; %s', 'woocommerce' ), strftime( _x( '%b %d, %Y @ %I:%M %p', 'Order date parsed by strftime', 'woocommerce' ) ) ),
		        'post_status'   => 'publish',
		        'ping_status'   => 'closed',
		        'post_excerpt'  => 'Auto-Ship Order based on original order ' . $original_order_id,
		        'post_author'   => $new_post_author->ID,
		        'post_password' => uniqid( 'order_' )   // Protects the post just in case
		   
   			);

			$new_post_id = wp_insert_post( $order_data, true );

			return $new_post_id;
		}

		private function duplicate_order_header($original_order_id, $order_id) {
			update_post_meta( $order_id, '_order_shipping',         get_post_meta($original_order_id, '_order_shipping', true) );
			update_post_meta( $order_id, '_order_discount',         get_post_meta($original_order_id, '_order_discount', true) );
			update_post_meta( $order_id, '_cart_discount',          get_post_meta($original_order_id, '_cart_discount', true) );
			update_post_meta( $order_id, '_order_tax',              get_post_meta($original_order_id, '_order_tax', true) );
			update_post_meta( $order_id, '_order_shipping_tax',     get_post_meta($original_order_id, '_order_shipping_tax', true) );
			update_post_meta( $order_id, '_order_total',            get_post_meta($original_order_id, '_order_total', true) );

			update_post_meta( $order_id, '_order_key',              'wc_' . apply_filters('woocommerce_generate_order_key', uniqid('order_') ) );
			update_post_meta( $order_id, '_customer_user',          get_post_meta($original_order_id, '_customer_user', true) );
			update_post_meta( $order_id, '_order_currency',         get_post_meta($original_order_id, '_order_currency', true) );
			update_post_meta( $order_id, '_prices_include_tax',     get_post_meta($original_order_id, '_prices_include_tax', true) );
			update_post_meta( $order_id, '_customer_ip_address',    get_post_meta($original_order_id, '_customer_ip_address', true) );
			update_post_meta( $order_id, '_customer_user_agent',    get_post_meta($original_order_id, '_customer_user_agent', true) );
		}

		private function duplicate_billing_fieds($original_order_id, $order_id) {
			update_post_meta( $order_id, '_billing_city',           get_post_meta($original_order_id, '_billing_city', true));
			update_post_meta( $order_id, '_billing_state',          get_post_meta($original_order_id, '_billing_state', true));
			update_post_meta( $order_id, '_billing_postcode',       get_post_meta($original_order_id, '_billing_postcode', true));
			update_post_meta( $order_id, '_billing_email',          get_post_meta($original_order_id, '_billing_email', true));
			update_post_meta( $order_id, '_billing_phone',          get_post_meta($original_order_id, '_billing_phone', true));
			update_post_meta( $order_id, '_billing_address_1',      get_post_meta($original_order_id, '_billing_address_1', true));
			update_post_meta( $order_id, '_billing_address_2',      get_post_meta($original_order_id, '_billing_address_2', true));
			update_post_meta( $order_id, '_billing_country',        get_post_meta($original_order_id, '_billing_country', true));
			update_post_meta( $order_id, '_billing_first_name',     get_post_meta($original_order_id, '_billing_first_name', true));
			update_post_meta( $order_id, '_billing_last_name',      get_post_meta($original_order_id, '_billing_last_name', true));
			update_post_meta( $order_id, '_billing_company',        get_post_meta($original_order_id, '_billing_company', true));
		}

		private function duplicate_shipping_fieds($original_order_id, $order_id) {
			update_post_meta( $order_id, '_shipping_country',       get_post_meta($original_order_id, '_shipping_country', true));
			update_post_meta( $order_id, '_shipping_first_name',    get_post_meta($original_order_id, '_shipping_first_name', true));
			update_post_meta( $order_id, '_shipping_last_name',     get_post_meta($original_order_id, '_shipping_last_name', true));
			update_post_meta( $order_id, '_shipping_company',       get_post_meta($original_order_id, '_shipping_company', true));
			update_post_meta( $order_id, '_shipping_address_1',     get_post_meta($original_order_id, '_shipping_address_1', true));
			update_post_meta( $order_id, '_shipping_address_2',     get_post_meta($original_order_id, '_shipping_address_2', true));
			update_post_meta( $order_id, '_shipping_city',          get_post_meta($original_order_id, '_shipping_city', true));
			update_post_meta( $order_id, '_shipping_state',         get_post_meta($original_order_id, '_shipping_state', true));
			update_post_meta( $order_id, '_shipping_postcode',      get_post_meta($original_order_id, '_shipping_postcode', true));
		}

	  	// TODO: same as duplicating order from user side
		private function duplicate_line_items($original_order, $order_id) {
			foreach($original_order->get_items() as $originalOrderItem){
				$itemName = $originalOrderItem['name'];
				$qty = $originalOrderItem['qty'];
				$lineTotal = $originalOrderItem['line_total'];
				$lineTax = $originalOrderItem['line_tax'];
				$productID = $originalOrderItem['product_id'];

				$item_id = wc_add_order_item( $order_id, array(
						'order_item_name'       => $itemName,
						'order_item_type'       => 'line_item'
				) );

				wc_add_order_item_meta( $item_id, '_qty', $qty );
	      		// TODO: Is it ok to uncomment this?
				wc_add_order_item_meta( $item_id, '_tax_class', $originalOrderItem['tax_class'] );
				wc_add_order_item_meta( $item_id, '_product_id', $productID );
	      		// TODO: Is it ok to uncomment this?
				wc_add_order_item_meta( $item_id, '_variation_id', $originalOrderItem['variation_id'] );
				wc_add_order_item_meta( $item_id, '_line_subtotal', wc_format_decimal( $lineTotal ) );
				wc_add_order_item_meta( $item_id, '_line_total', wc_format_decimal( $lineTotal ) );
				/* wc_add_order_item_meta( $item_id, '_line_tax', wc_format_decimal( '0' ) ); */
				wc_add_order_item_meta( $item_id, '_line_tax', wc_format_decimal( $lineTax ) );
	      		// TODO: Is it ok to uncomment this?
				/* wc_add_order_item_meta( $item_id, '_line_subtotal_tax', wc_format_decimal( '0' ) ); */
				wc_add_order_item_meta( $item_id, '_line_subtotal_tax', wc_format_decimal( $originalOrderItem['line_subtotal_tax'] ) );
			}

			// TODO This is what is in order_again of class-wc-form-handler.php  
			// Can it be reused or refactored into own function?
			//
				// Copy products from the order to the cart
				/* foreach ( $order->get_items() as $item ) { */
				/* 	// Load all product info including variation data */
				/* 	$product_id   = (int) apply_filters( 'woocommerce_add_to_cart_product_id', $item['product_id'] ); */
				/* 	$quantity     = (int) $item['qty']; */
				/* 	$variation_id = (int) $item['variation_id']; */
				/* 	$variations   = array(); */
				/* 	$cart_item_data = apply_filters( 'woocommerce_order_again_cart_item_data', array(), $item, $order ); */

				/* 	foreach ( $item['item_meta'] as $meta_name => $meta_value ) { */
				/* 		if ( taxonomy_is_product_attribute( $meta_name ) ) { */
				/* 			$variations[ $meta_name ] = $meta_value[0]; */
				/* 		} elseif ( meta_is_product_attribute( $meta_name, $meta_value[0], $product_id ) ) { */
				/* 			$variations[ $meta_name ] = $meta_value[0]; */
				/* 		} */
				/* 	} */
		}

		private function duplicate_shipping_items($original_order, $order_id) {
			$original_order_shipping_items = $original_order->get_items('shipping');

			foreach ( $original_order_shipping_items as $original_order_shipping_item ) {
				$item_id = wc_add_order_item( $order_id, array(
					'order_item_name'       => $original_order_shipping_item['name'],
					'order_item_type'       => 'shipping'
				) );
				if ( $item_id ) {
					wc_add_order_item_meta( $item_id, 'method_id', $original_order_shipping_item['method_id'] );
					wc_add_order_item_meta( $item_id, 'cost', wc_format_decimal( $original_order_shipping_item['cost'] ) );

	        		// TODO: Does not store the shipping taxes
					/* wc_add_order_item_meta( $item_id, 'taxes', $original_order_shipping_item['taxes'] ); */
				}
			}
		}

		private function duplicate_coupons($original_order, $order_id) {
			$original_order_coupons = $original_order->get_items('coupon');
			foreach ( $original_order_coupons as $original_order_coupon ) {
				$item_id = wc_add_order_item( $order_id, array(
					'order_item_name'       => $original_order_coupon['name'],
					'order_item_type'       => 'coupon'
				) );
				// Add line item meta
				if ( $item_id ) {
					wc_add_order_item_meta( $item_id, 'discount_amount', $original_order_coupon['discount_amount'] );
				}
			}
		}

		private function duplicate_payment_info($original_order_id, $order_id, $order) {
			update_post_meta( $order_id, '_payment_method',         get_post_meta($original_order_id, '_payment_method', true) );
			update_post_meta( $order_id, '_payment_method_title',   get_post_meta($original_order_id, '_payment_method_title', true) );
			/* update_post_meta( $order->id, 'Transaction ID',         get_post_meta($original_order_id, 'Transaction ID', true) ); */
			/* $order->payment_complete(); */
		}

		private function add_order_note($original_order_id, $order) {
			$updateNote = 'This order was duplicated from order ' . $original_order_id . '.';
			/* $order->update_status('processing'); */
			$order->add_order_note($updateNote);
		}


    }
}

add_action('wp_selcom_check_order_status_cron', 'check_order_statuses_func');

function check_order_statuses_func() {
	$orders = wc_get_orders([
		'limit'    => -1,
        'status'   => 'pending'
    ]);
    
    if ($orders > 0) {
        foreach ($orders as $value) {
            $order_id = $value->id;
			$gateway = new WP_Selcom_Payment_Gateway();
            $gateway->check_order_statuses($order_id);
        }
    }
}

add_action('wp_ajax_set_payment_method', 'set_payment_method');
add_action('wp_ajax_nopriv_set_payment_method', 'set_payment_method');

function set_payment_method() {
    if (!session_id()) {
        session_start();
    }
	
    if (isset($_POST['payment_method'])) {
        $_SESSION['selected_payment_method'] = array_map('sanitize_text_field', (array)$_POST['payment_method']);

        wp_send_json_success('Payment method updated.');
    } else {
        wp_send_json_error('Payment method not set.');
    }
}